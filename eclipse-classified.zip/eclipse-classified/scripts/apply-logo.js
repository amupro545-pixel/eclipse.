// Copies the Eclipse logo icons into the Android project (run after "npx cap add android").
const fs = require('fs');
const path = require('path');

const from = path.join(__dirname, '..', 'android-res');
const to = path.join(__dirname, '..', 'android', 'app', 'src', 'main', 'res');

if (!fs.existsSync(path.join(__dirname, '..', 'android'))) {
  console.log('No android folder yet. Run "npx cap add android" first, then "npm run logo".');
  process.exit(0);
}

function copyDir(src, dst) {
  fs.mkdirSync(dst, { recursive: true });
  for (const e of fs.readdirSync(src, { withFileTypes: true })) {
    const s = path.join(src, e.name), d = path.join(dst, e.name);
    if (e.isDirectory()) copyDir(s, d); else fs.copyFileSync(s, d);
  }
}

copyDir(from, to);

// remove the default placeholder icon vectors that Capacitor generates, so only the Eclipse logo is left
for (const f of ['drawable/ic_launcher_background.xml', 'drawable-v24/ic_launcher_foreground.xml']) {
  const p = path.join(to, f);
  if (fs.existsSync(p)) fs.unlinkSync(p);
}
console.log('Eclipse logo applied to the Android app icon.');
