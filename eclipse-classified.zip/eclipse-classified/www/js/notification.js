/* Eclipse - streak notifications: hourly reminders, danger warnings, auto reset, real phone notifications (Capacitor) */
    /* ===== STREAK NOTIFICATIONS =====
       Every day is a 24 h window counted from the moment the streak started. While today's tasks are not
       finished a reminder is due every hour (Stay disciplined -> days left -> one of your tasks), the last
       10 minutes give a danger warning, and when the window ends unfinished the streak resets.

       * Inside the installed Android app (Capacitor) every reminder is handed to the phone's own alarm
         scheduler ahead of time, so real notifications appear even when the app is closed.
       * In a plain browser / HTML viewer only the in-app glass banner (and a browser notification while the
         page is in the background) is possible. */
    const DAY_MS = 24 * 60 * 60 * 1000;
    const HOUR_MS = 60 * 60 * 1000;
    const notifPill = document.getElementById('notifPill');
    let notifShowing = false;
    let notifEnabled = localStorage.getItem('notifEnabled') !== 'false';

    function nativeLN() { return (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.LocalNotifications) || null; }

    function getStreakStart() {
      let st = parseInt(localStorage.getItem('streakStart'), 10);
      if (!st) {
        st = Date.now() - (Math.max(1, currentDay) - 1) * DAY_MS;   // existing progress: today's window starts now
        localStorage.setItem('streakStart', String(st));
      }
      return st;
    }

    function streakClock() {
      const st = getStreakStart();
      return { winStart: st + (currentDay - 1) * DAY_MS, deadline: st + currentDay * DAY_MS };
    }

    function todayDone() {
      return tasks.length > 0 && tasks.every(t => t.checklist.length > 0 && t.checklist.every(x => x.done));
    }

    function streakActive() {
      return TOTAL_DAYS > 0 && tasks.length > 0 && completedCount() < TOTAL_DAYS;
    }

    function accentHexNow() {
      const a = (colorPresets[selectedColor] || colorPresets.black).accent;
      return a === '#000000' ? '#ffffff' : a;
    }

    function notifIconUri() {
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><rect width="24" height="24" rx="6" fill="#000"/><path d="M12 22C16.1 22 19.5 18.9 19.5 15C19.5 11.2 16.5 7.8 13.5 3.5C13.1 2.9 12.2 3.1 12.1 3.8C11.5 7 9.8 8.8 8 10.5C6.2 12.3 4.5 13.8 4.5 16.8C4.5 19.7 7.9 22 12 22Z" fill="${accentHexNow()}"/></svg>`;
      return 'data:image/svg+xml;utf8,' + encodeURIComponent(svg);
    }

    function openHomeFromNotification() {
      try { window.focus(); } catch (e) {}
      closeAll();
      switchTab('home');
    }

    function hideNotifBanner() {
      notifPill.style.display = 'none';
      notifPill.classList.remove('notif-run', 'danger');
      notifShowing = false;
    }

    function showNotifBanner(title, sub, danger) {
      if (notifShowing) return false;
      document.getElementById('notifTitle').textContent = title;
      document.getElementById('notifSub').textContent = sub;
      notifPill.classList.toggle('danger', !!danger);
      notifPill.style.setProperty('--notif-dur', danger ? '8s' : '5.4s');
      notifPill.style.display = 'flex';
      notifPill.classList.remove('notif-run');
      void notifPill.offsetWidth;
      notifPill.classList.add('notif-run');
      notifShowing = true;
      return true;
    }

    notifPill.addEventListener('animationend', (e) => { if (e.target === notifPill) hideNotifBanner(); });
    notifPill.addEventListener('click', () => { hideNotifBanner(); openHomeFromNotification(); });

    // ---- the text of every hourly slot (slot k is due at windowStart + k hours) ----
    function openTaskNames() {
      const open = tasks.filter(t => !(t.checklist.length > 0 && t.checklist.every(x => x.done)));
      return (open.length ? open : tasks).map(t => t.name);
    }

    function daysLeftText() {
      const left = Math.max(0, TOTAL_DAYS - completedCount());
      return left === 1 ? 'Only 1 day left' : `Only ${left} days left`;
    }

    function slotText(k, names) {
      const phase = (k - 1) % 3;
      if (phase === 0) return 'Stay disciplined';
      if (phase === 1) return daysLeftText();
      const list = names || openTaskNames();
      return list[Math.floor((k - 1) / 3) % list.length];   // a different task every time
    }

    // ---- in-app / browser delivery ----
    function notify(title, sub, danger) {
      if (document.visibilityState === 'visible') return showNotifBanner(title, sub, danger);
      if ('Notification' in window && Notification.permission === 'granted') {
        try {
          const n = new Notification(title, { body: sub, icon: notifIconUri(), tag: 'eclipse-streak', renotify: true });
          n.onclick = () => { openHomeFromNotification(); n.close(); };
          return true;
        } catch (e) {}
      }
      return false;
    }

    function autoResetStreak() {
      currentDay = 1;
      highestUnlockedDay = 1;
      completedDays = [];
      dayTaskHistory = {};
      localStorage.setItem('completedDays', '[]');
      localStorage.setItem('highestUnlockedDay', '1');
      localStorage.setItem('challengeDay', '1');
      localStorage.setItem('dayTaskHistory', '{}');
      localStorage.setItem('streakStart', String(Date.now()));
      saveAndReloadTasks();
      renderProgress();
      renderTasks();
      closeAll();
      hideNotifBanner();
      if (notifEnabled) showNotifBanner('Your streak was reset', 'You missed a day, so you start again from day 1', true);
      scheduleNativeSoon(true);
    }

    function streakTick() {
      if (!streakActive() || todayDone()) return;
      const now = Date.now();
      const { winStart, deadline } = streakClock();

      if (now >= deadline) { autoResetStreak(); return; }          // the day passed unfinished
      if (!notifEnabled || now < winStart) return;
      if (nativeLN()) return;                                        // the phone's own notifications do the reminding

      const left = deadline - now;
      const key = `${getStreakStart()}|${currentDay}`;
      if (left <= 10 * 60000) {                                      // danger: the last 10 minutes
        const mins = Math.max(1, Math.ceil(left / 60000));
        const mark = [10, 5, 2].filter(m => mins <= m).pop();
        const sent = localStorage.getItem('notifDanger') || '';
        const tag = `${key}|${mark}`;
        if (mark && !sent.split(',').includes(tag)) {
          if (notify("Don't miss your streak", `Danger: only ${mins} minute${mins === 1 ? '' : 's'} left. Your streak will reset!`, true)) {
            localStorage.setItem('notifDanger', (sent ? sent + ',' : '') + tag);
          }
        }
        return;
      }

      const k = Math.floor((now - winStart) / HOUR_MS);              // the latest hourly slot that is due
      if (k >= 1 && localStorage.getItem('notifSlot') !== `${key}|${k}`) {
        if (notify("Don't miss your streak", slotText(k), false)) localStorage.setItem('notifSlot', `${key}|${k}`);
      }
    }

    // ---- real phone notifications (installed Android app) ----
    let nativeSig = '';
    let nativeTimer = null;

    function buildNativePlan() {
      const now = Date.now();
      const { winStart, deadline } = streakClock();
      const names = openTaskNames();
      const color = accentHexNow();
      const base = { channelId: 'streak', iconColor: color };
      const plan = [];
      const cut = deadline - 10 * 60000;
      for (let k = 1; winStart + k * HOUR_MS < cut && plan.length < 60; k++) {
        const ts = winStart + k * HOUR_MS;
        if (ts <= now + 5000) continue;
        plan.push({ ...base, id: 1000 + k, title: "Don't miss your streak", body: slotText(k, names), schedule: { at: new Date(ts), allowWhileIdle: true } });
      }
      [10, 5, 2].forEach((m, i) => {
        const ts = deadline - m * 60000;
        if (ts > now + 5000) plan.push({ ...base, id: 10 + i, title: "Don't miss your streak", body: `Danger: only ${m} minutes left. Your streak will reset!`, schedule: { at: new Date(ts), allowWhileIdle: true } });
      });
      if (deadline > now + 5000) plan.push({ ...base, id: 20, title: 'Your streak ended', body: 'You missed a day. Open the app to start again from day 1.', schedule: { at: new Date(deadline), allowWhileIdle: true } });
      return plan;
    }

    async function scheduleNative(force) {
      const LN = nativeLN();
      if (!LN) return;
      const sig = [notifEnabled, streakActive(), todayDone(), getStreakStart(), currentDay, completedCount(), tasks.map(t => t.name).join('|'), accentHexNow()].join('~');
      if (!force && sig === nativeSig) return;
      nativeSig = sig;
      try {
        await LN.createChannel({ id: 'streak', name: 'Streak reminders', description: 'Reminders to finish your daily tasks', importance: 5, visibility: 1, vibration: true, lights: true });
        const pending = await LN.getPending();
        if (pending && pending.notifications && pending.notifications.length) {
          await LN.cancel({ notifications: pending.notifications.map(n => ({ id: n.id })) });
        }
        if (!notifEnabled || !streakActive() || todayDone()) return;
        const plan = buildNativePlan();
        if (plan.length) await LN.schedule({ notifications: plan });
      } catch (e) { nativeSig = ''; }
    }

    function scheduleNativeSoon(force) {
      if (!nativeLN()) return;
      clearTimeout(nativeTimer);
      nativeTimer = setTimeout(() => scheduleNative(force), 400);
    }

    function initNativeListeners() {
      const LN = nativeLN();
      if (!LN || !LN.addListener) return;
      // app is open when a reminder fires: show the glass banner and remove the phone's copy
      LN.addListener('localNotificationReceived', (n) => {
        showNotifBanner(n.title || "Don't miss your streak", n.body || '', n.id >= 10 && n.id <= 20);
        try { LN.removeDeliveredNotifications({ notifications: [n] }); } catch (e) {}
      });
      LN.addListener('localNotificationActionPerformed', () => openHomeFromNotification());
    }

    // ---- permission + settings switch ----
    function syncNotifToggle() {
      const t = document.getElementById('notifToggle');
      if (t) t.checked = notifEnabled;
    }

    // asks the REAL phone permission (Android system dialog in the installed app, browser prompt in a browser)
    async function requestRealPermission() {
      const LN = nativeLN();
      if (LN) {
        try {
          const r = await LN.requestPermissions();
          return r && r.display === 'granted';
        } catch (e) { return false; }
      }
      if (!('Notification' in window)) return false;
      if (Notification.permission === 'granted') return true;
      if (Notification.permission === 'denied') return false;
      try { return (await Notification.requestPermission()) === 'granted'; } catch (e) { return false; }
    }

    async function notifAnswer(allow) {
      localStorage.setItem('notifAsked', '1');
      notifEnabled = !!allow;
      localStorage.setItem('notifEnabled', String(notifEnabled));
      syncNotifToggle();
      closeAll();
      if (allow) {
        const ok = await requestRealPermission();
        if (!ok) showNotifBanner('Notifications are blocked', 'Allow them for this app in your phone settings', false);
      }
      scheduleNativeSoon(true);
    }

    async function setNotifEnabled(on) {
      notifEnabled = !!on;
      localStorage.setItem('notifEnabled', String(notifEnabled));
      localStorage.setItem('notifAsked', '1');
      if (on) {
        const ok = await requestRealPermission();
        if (!ok) showNotifBanner('Notifications are blocked', 'Allow them for this app in your phone settings', false);
      }
      scheduleNativeSoon(true);
    }

    function initNotifications() {
      syncNotifToggle();
      initNativeListeners();
      if (!localStorage.getItem('notifAsked')) {
        setTimeout(() => {
          closeAll();
          document.getElementById('notifPermModal').classList.add('open');
          overlay.classList.add('active');
        }, 500);
      }
      streakTick();
      scheduleNativeSoon(true);
      setInterval(() => { streakTick(); scheduleNativeSoon(false); }, 20000);
      document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') { streakTick(); scheduleNativeSoon(true); } });
    }

    if (document.getElementById('eclipse-splash')) document.addEventListener('splashdone', initNotifications, { once: true });
    else initNotifications();
