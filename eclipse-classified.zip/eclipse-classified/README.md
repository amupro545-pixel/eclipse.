# Eclipse – classified project

Open `www/index.html` in a browser to run the app. Nothing is loaded from the internet.

```
eclipse-classified/
├── www/                         the app
│   ├── index.html               page shell: all markup + links to the files below
│   ├── css/
│   │   ├── styles.css           main styles: layout, dark/light themes, glass components, modals, calendar, settings
│   │   ├── notification.css     streak notification: glass banner, danger look, settings switch, permission popup
│   │   └── splash.css           opening animation: ring, typing, caret, neon
│   ├── js/
│   │   ├── app.js               main logic: tasks, streak days, themes, navigation, calendar, colour picker, gestures
│   │   ├── notification.js      reminders every hour, danger warnings, auto reset, real phone notifications
│   │   └── splash.js            opening animation script
│   └── html/                    the markup pieces below, kept as separate reference copies
│       ├── notification.html    notification banner + permission popup + the Settings switch row
│       └── splash.html          opening animation markup
├── www/icons/                   the Eclipse logo: logo.png (original), icon-512.png, icon-192.png, favicon.png
├── www/manifest.json            JSON: web app manifest (name + logo for "Add to Home screen")
├── android-res/                 the logo as Android launcher icons (all sizes, adaptive + round) on a black background
├── assets/                      logo sources (1024 px) if you prefer `npx @capacitor/assets generate --android`
├── scripts/apply-logo.js        puts android-res into the Android project
├── package.json                 JSON: Android app dependencies (Capacitor + Local Notifications)
├── capacitor.config.json        JSON: Android app settings (name, folder `www`, notification icon colour)
└── AndroidManifest-additions.txt  permission lines to add when building the Android app
```

Load order in `index.html` (do not change): `css/styles.css`, `css/notification.css`, `css/splash.css`,
then at the end `js/splash.js`, `js/app.js`, `js/notification.js`.
The files are the single-file app cut into pieces without any change, so the app works exactly the same.

## Real phone notifications (Android app)
1. Install Node.js and Android Studio.
2. In this folder run: `npm install` then `npx cap add android`
3. Run `npm run logo`  - this replaces the default Capacitor icon with the Eclipse logo
4. Add the lines from `AndroidManifest-additions.txt` to `android/app/src/main/AndroidManifest.xml`
5. Run `npx cap sync android` then `npx cap open android`, then Build > Build APK(s)
6. Install the APK on the phone, open it and tap Allow on the real Android permission dialog.
On Android 14 also allow "Alarms & reminders" for the app, and set its battery use to "Unrestricted".
